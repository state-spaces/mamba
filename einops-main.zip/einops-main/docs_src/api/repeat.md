# einops.repeat

::: einops.repeat