# einops.asnumpy

::: einops.asnumpy