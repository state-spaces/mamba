# einops.rearrange

::: einops.rearrange