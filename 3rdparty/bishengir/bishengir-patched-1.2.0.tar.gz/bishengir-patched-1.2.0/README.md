# bishengir-compile 1.2.0 (patched)

CANN 9.1.0 自带的 `bishengir-compile` 在 `ConvertHFusionToHIVM` 里对一个
buffer 语义的 `mmadL1`（0 个 result）做 `op.getResult(0)`，越界读导致随机 SIGSEGV。
这里是与 CANN 同 commit（`8796a8a` = v1.2.0）的源码加上一行 guard 后重链出来的二进制：

    if (op->getNumResults() == 0) return;

用法（唯一的入口是 wrapper，它会把 hivmc 垫片放进 PATH）：

    export TILELANG_NPU_COMPILER_PATH=/mnt/zsj/tools/bishengir-patched-1.2.0/bin/tl-bishengir-compile

不要直接把 `TILELANG_NPU_COMPILER_PATH` 指向 `bin/bishengir-compile`：CANN 的 hivmc
不接受这个二进制默认透传的 `--enable-lir-compile` / `--enable-cpu-trace-intrinsic`，
wrapper 会先落到 `shimdir/hivmc` 把它们去掉。

目录：`bin/`（二进制 + wrapper）、`lib/`（它需要的 14 个 .bc）、`shimdir/hivmc`。
整目录可以整体搬走，wrapper 用自身位置定位，不依赖绝对路径。
